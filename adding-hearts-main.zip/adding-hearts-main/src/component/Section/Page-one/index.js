export { default as Hero } from "./Hero-section/Hero";
export { default as About_US } from "./About-us-section/About_US";
export { default as Timeline } from "./Timeline-section/Timeline";
export { default as Sponser } from "./Sponser-section/Sponser";
export { default as Latest } from "./Latest-section/Latest";
export { default as Chariti_Page_Wrapper } from "./Chariti-page-wrapper-section/Chariti_Page_Wrapper";
export { default as Our_Latest_News } from "./Our-latest-news-section/Our_Latest_News";
export { default as Help_Me } from "./Help-me-section/Help_Me";
