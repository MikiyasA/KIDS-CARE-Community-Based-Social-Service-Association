export { default as Hero } from "./Hero-section/Hero";
export { default as About_US } from "./About-us-section/About_US";
export { default as What_We } from "./What-we-section/What_We";
